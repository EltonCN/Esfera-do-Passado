Para Windows: (For Windows:)
Execute "EsferaDoTempo.exe"

Para Linux: (For Linux:)
Execute "EsferaDoTempo.x86_64"